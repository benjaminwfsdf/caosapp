Proyecto CAOS - versión funcional base
Sube esta carpeta a GitHub y luego conéctala a Vercel.